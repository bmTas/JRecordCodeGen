CodeGen - Package for generating Code from a Cobol Copybook.

This Zip file conains an example of writing  a CodeGen Template
and then generating it using either the RecordEditor or the CodeGen jar file.

see either:

* MdtTemplate.html
* https://sourceforge.net/p/jrecord/wiki/CodeGen%20Example%201/
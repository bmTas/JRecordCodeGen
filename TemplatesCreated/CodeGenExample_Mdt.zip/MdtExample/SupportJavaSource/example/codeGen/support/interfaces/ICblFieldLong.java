package example.codeGen.support.interfaces;

public interface ICblFieldLong {

    public boolean isPresent();
    public void setPresent(boolean present);

    public long get();
    public void set(long value);
}

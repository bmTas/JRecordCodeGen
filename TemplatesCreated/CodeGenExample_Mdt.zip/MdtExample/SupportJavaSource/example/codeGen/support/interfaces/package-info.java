/**
 * 
 */
/**
 * @author bruce
 *
 */
package example.codeGen.support.interfaces;